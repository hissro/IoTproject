enum Options { timer, cooling, heat, dry }
