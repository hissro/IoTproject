package com.iotuichallenge.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
